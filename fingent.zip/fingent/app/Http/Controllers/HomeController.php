<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $reportingmanager = DB::table('teacher')
                                ->select('*')
                            ->get();
                        //    dd($reportingmanager);
    return view('welcome',['reportingmanager'=>$reportingmanager]);

    }
    public function view()
    {
        $data = DB::table('student')
               // ->join('teacher','student.teacher','=','teacher.code')
                ->select('*')
            ->get();
        $reportingmanager = DB::table('teacher')
            ->select('*')
        ->get();
       // dd($data);
        return view('sudenttable',['data'=>$data,'reportingmanager' => $reportingmanager]);

    }
    public function mark()
    {
        $data = DB::table('student_mark')
               // ->join('teacher','student.teacher','=','teacher.code')
                ->select('*')
            ->get();
        $reportingmanager = DB::table('teacher')
            ->select('*')
        ->get();
       // dd($data);
        return view('student_mark',['data'=>$data,'reportingmanager' => $reportingmanager]);

    }
    public function teacher()
    {
        $data = DB::table('teacher')
               // ->join('teacher','student.teacher','=','teacher.code')
                ->select('*')
            ->get();
        
       // dd($data);
        return view('teacher',['data'=>$data]);

    }
    public function mark_view()
    {
        $data = DB::table('student')
               // ->join('teacher','student.teacher','=','teacher.code')
                ->select('*')
            ->get();
        $reportingmanager = DB::table('teacher')
            ->select('*')
        ->get();
       // dd($data);
        return view('create_mark',['name' => $data]);

    }
    public function teacher_view()
    {
        $data = DB::table('teacher')
                ->select('*')
            ->get();;
        return view('create_teacher');

    }
    

    

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        DB::table('student')->insert(
            [   
                'name'		=> $request->input('name'),
                'Age'		=> $request->input('Age'),
                'Gender'		=> $request->input('gender'),
                'teacher'		=> $request->input('Teacher'),
                'status'		=> 1
            
         ]);
        $data = DB::table('student')
            ->select('*')
        ->get();
        $reportingmanager = DB::table('teacher')
            ->select('*')
        ->get();
         return view('sudenttable',['data'=>$data, 'reportingmanager'=>$reportingmanager]);
         
    }

    public function store_mark(Request $request)
    {
        $total = $request->input('Maths') + $request->input('Science') + $request->input('History');
        DB::table('student_mark')->insert(
            [   
                'name'		=> $request->input('Name'),
                'maths'		=> $request->input('Maths'),
                'Science'		=> $request->input('Science'),
                'History'		=> $request->input('History'),
                'term'		=> $request->input('Term'),
                'totalmark'		=> $total,
                'created_at'		=> date("Y-m-d H:i:s") ,
                'updated_at'		=> date("Y-m-d H:i:s") ,
                'status'		=> 1
         ]);
         $data = DB::table('student_mark')
                ->select('*')
            ->get();
        $reportingmanager = DB::table('teacher')
            ->select('*')
        ->get();
        return view('student_mark',['data'=>$data,'reportingmanager' => $reportingmanager]);
         
    }
    public function store_teacher(Request $request)
    {
        DB::table('teacher')->insert(
            [   
                'name'		=> $request->input('name'),
                'code'		=> $request->input('code'),
                'status'		=> 1
         ]);
         $data = DB::table('teacher')
                ->select('*')
            ->get();
        return view('teacher',['data'=>$data]);
         
    }

    public function storeput(Request $request)
    {
        DB::table('student')->where('id',$request->input('id'))->update(
            [   
                'name'		=> $request->input('name'),
                'Age'		=> $request->input('Age'),
                'Gender'		=> $request->input('gender'),
                'teacher'		=> $request->input('Teacher'),
                'status'		=> 1
            
         ]);
        $data = DB::table('student')
            ->select('*')
        ->get();
        $reportingmanager = DB::table('teacher')
            ->select('*')
        ->get();
         return view('sudenttable',['data'=>$data, 'reportingmanager'=>$reportingmanager]);
         
    }
    public function mark_post(Request $request)
    {
        $total = $request->input('Maths') + $request->input('Science') + $request->input('History');
        DB::table('student_mark')->where('id',$request->input('id'))->update(
            [   
                'name'		=> $request->input('Name'),
                'maths'		=> $request->input('Maths'),
                'Science'		=> $request->input('Science'),
                'History'		=> $request->input('History'),
                'term'		=> $request->input('Term'),
                'totalmark'		=> $total,
                'created_at'		=> date("Y-m-d H:i:s") ,
                'updated_at'		=> date("Y-m-d H:i:s"),
                'status'		=> 1
            
         ]);
         $data = DB::table('student_mark')
                ->select('*')
             ->get();
        $reportingmanager = DB::table('teacher')
                ->select('*')
            ->get();
         return view('student_mark',['data'=>$data, 'reportingmanager'=>$reportingmanager]);
         
    }
    public function teacher_post(Request $request)
    {
        DB::table('teacher')->where('id',$request->input('id'))->update(
            [   
                'name'		=> $request->input('name'),
                'code'		=> $request->input('code'),
                'status'		=> 1
            
         ]);
         $data = DB::table('teacher')
                ->select('*')
             ->get();

         return view('teacher',['data'=>$data]);
         
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    
    public function editStudent($id)
    {
        $data = DB::table('student')
            ->select('*')
            ->where('id',$id)
        ->get();
        
        $reportingmanager = DB::table('teacher')
            ->select('*')
        ->get();

    return view('welcome',['reportingmanager'=>$reportingmanager,'data'=>$data]);
    }
    public function edit_teacher($id)
    {
        $data = DB::table('teacher')
            ->select('*')
            ->where('id',$id)
        ->get();
        
        $reportingmanager = DB::table('teacher')
            ->select('*')
        ->get();

    return view('create_teacher',['data'=>$data]);
    }
    public function edit_mark($id)
    {
        $data = DB::table('student_mark')
            ->select('*')
            ->where('id',$id)
        ->get();
        
        $name = DB::table('student')
            ->select('*')
        ->get();

    return view('create_mark',['name'=>$name,'data'=>$data]);
    }

  
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::table('student')
                ->where('id',  $id)
            ->delete();
        $data = DB::table('student')
        ->select('*')
        ->get();
        $reportingmanager = DB::table('teacher')
            ->select('*')
        ->get();
         return view('sudenttable',['data'=>$data, 'reportingmanager'=>$reportingmanager]);
    }
    public function destroy_mark($id)
    {
        DB::table('student_mark')
                ->where('id',  $id)
            ->delete();
            $data = DB::table('student_mark')
            ->select('*')
         ->get();
        $reportingmanager = DB::table('teacher')
                ->select('*')
            ->get();
        return view('student_mark',['data'=>$data, 'reportingmanager'=>$reportingmanager]);
    }
    public function destroy_teacher($id)
    {
        DB::table('teacher')
                ->where('id',  $id)
            ->delete();
            $data = DB::table('teacher')
            ->select('*')
         ->get();
      
        return view('teacher',['data'=>$data]);
    }
}
