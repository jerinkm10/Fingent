<!DOCTYPE html>
<html lang="en">
<head>
  <title>FINGENT </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Student Mark Table</h2>
  <a href="/student_mark"class="btn btn-success">CREATE</a>
  <a href="/"class="btn btn-info">Back</a>
  <table class="table table-dark table-hover">
    <thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Maths</th>
        <th>Science</th>
        <th>History</th>
        <th>Total marks</th>
        <th>Create ON</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php if(!empty($data)){?>
        @foreach($data as $value)  
        
      <tr>
        <td>{{$value->id}}</td>
        <td>{{$value->maths}}</td>
        <td>{{$value->Science}}</td>
        <td>{{$value->History}}</td>
        <td>{{$value->term}}</td>
        <td>{{$value->totalmark}}</td>
        <td>{{$value->created_at}}</td>
        <td><a href="/student_mark/{{$value->id}}" class="btn btn-success btn-sm">edit</a>
        <a href="/delete_mark/{{$value->id}}" class="btn btn-danger btn-sm">Delete</a></td>
      </tr>
      @endforeach
    <?php } ?>
    </tbody>
  </table>
</div>

</body>
</html>
