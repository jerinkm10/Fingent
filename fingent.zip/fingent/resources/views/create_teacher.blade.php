<!DOCTYPE html>
<html lang="en">
<head>
  <title>FINGENT </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Student Detaills</h2>
  
  <?php if(empty($data)) {?>
  <form action="/teacher" method="post">
      @csrf
    <div class="form-group">
      <label for="uname">NAME:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name" required>
    </div>
    <div class="form-group">
      <label for="uname">Age:</label>
      <input type="text" class="form-control" id="code" placeholder="code " name="code" required>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  <?php }else {?>
    @foreach($data as $value)
  <form action="/teacher_post" method="post">
      @csrf
      <input type="hidden"  id="id"  value='{{$value->id}}' name="id" >   
      <div class="form-group">
      <label for="uname">NAME:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Name" value="{{$value->name}}"name="name" required>
    </div>
    <div class="form-group">
      <label for="uname">Age:</label>
      <input type="text" class="form-control" id="code" placeholder="code "value="{{$value->code}}"name="code" required>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  @endforeach
  <?php } ?>
</div>

</body>
</html>
