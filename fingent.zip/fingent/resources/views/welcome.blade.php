<!DOCTYPE html>
<html lang="en">
<head>
  <title>FINGENT </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Student Detaills</h2>
  
  <?php if(empty($data)) {?>
  <form action="/student" method="post">
      @csrf
    <div class="form-group">
      <label for="uname">NAME:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name" required>
    </div>
    <div class="form-group">
      <label for="uname">Age:</label>
      <input type="text" class="form-control" id="age" placeholder="Age " name="Age" required>
    </div>
    <div class="form-group">
            <label for="sel1">Gender:</label>
            <select class="form-control" id="gender"  name="gender" placeholder="Gender" required>
                <option value="">Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
        </div> 
        <div class="form-group">
            <label for="sel1">Reporting Teacher:</label>
            <select class="form-control" id="Reporting_teacher"  name="Teacher" required>
                <option></option>
              <?php   if(!empty($reportingmanager)) { ?> 
                @foreach($reportingmanager as $value)
                     <option value="{{$value->code}}">{{$value->name}}</option>  
                @endforeach
              <?php }
               ?>
            </select>
        </div> 
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  <?php }else {?>
    @foreach($data as $value)
  <form action="/student_post" method="post">
      @csrf
      <input type="hidden"  id="id"  value='{{$value->id}}' name="id" >   
    <div class="form-group">
      <label for="uname">NAME:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Name" value='{{$value->name}}' name="name" required>
    </div>
    <div class="form-group">
      <label for="uname">Age:</label>
      <input type="text" class="form-control" id="age" placeholder="Age " value='{{$value->Age}}' name="Age" required>
    </div>
    <div class="form-group">
            <label for="sel1">Gender:</label>
            <select class="form-control" id="gender"  name="gender" placeholder="Gender" required>
                <option  value='{{$value->Gender}}'>{{$value->Gender}}</option>
                <option value="">Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
        </div> 
        <div class="form-group">
            <label for="sel1">Reporting Teacher:</label>
            <select class="form-control" id="Reporting_teacher"  name="Teacher" required>
              
              <?php   if(!empty($reportingmanager)) { ?> 
                @foreach($reportingmanager as $values)
                    @if($values->code == $value->teacher)
                    <option  value='{{$values->code}}' style='color:red'>{{$values->name}}</option>
                    @endif
                     <option value="{{$values->code}}">{{$values->name}}</option>  
                @endforeach
              <?php } ?>
            </select>
        </div> 
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  @endforeach
  <?php } ?>
</div>

</body>
</html>
