<!DOCTYPE html>
<html lang="en">
<head>
  <title>MARK STUDENT </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Student Mark</h2>
  
  <?php if(empty($data)) {?>
    <form action="/Mark_post" method="post">
        @csrf
        <div class="form-group">
            <label for="sel1">Name:</label>
            <select class="form-control" id="Name"  name="Name" required>
            <?php   if(!empty($name)) { ?> 
                @foreach($name as $values)
                    <option value="{{$values->name}}">{{$values->name}}</option>  
                @endforeach
            <?php } ?>
            </select>
        </div> 
        <div class="form-group">
        <label for="uname">Maths:</label>
        <input type="number" class="form-control" id="Maths" placeholder="Maths " name="Maths" required>
        </div>
        <div class="form-group">
        <label for="uname">Science:</label>
        <input type="number" class="form-control" id="Science" placeholder="Science " name="Science" required>
        </div>
        <div class="form-group">
        <label for="uname">History:</label>
        <input type="number" class="form-control" id="History" placeholder="History " name="History" required>
        </div>
        <div class="form-group">
        <label for="uname">Term:</label>
        <input type="text" class="form-control" id="Term" placeholder="Term " name="Term" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  <?php }else {?>
    @foreach($data as $value)
  <form action="/mark_post" method="post">
      @csrf
      <input type="hidden"  id="id"  value='{{$value->id}}' name="id" >   
      <div class="form-group">
            <label for="sel1">Name:</label>
            <select class="form-control" id="Name"  name="Name" required>
            <option value="{{$value->name}}">{{$value->name}}</option>  
            <?php   if(!empty($name)) { ?> 
                @foreach($name as $values)
                    <option value="{{$values->name}}">{{$values->name}}</option>  
                @endforeach
            <?php } ?>
            </select>
        </div> 
        <div class="form-group">
        <label for="uname">Maths:</label>
        <input type="number" class="form-control" id="Maths" placeholder="Maths " value="{{$value->maths}}" name="Maths" required>
        </div>
        <div class="form-group">
        <label for="uname">Science:</label>
        <input type="number" class="form-control" id="Science" placeholder="Science "  value="{{$value->Science}}" name="Science" required>
        </div>
        <div class="form-group">
        <label for="uname">History:</label>
        <input type="number" class="form-control" id="History" placeholder="History " value="{{$value->History}}" name="History" required>
        </div>
        <div class="form-group">
        <label for="uname">Term:</label>
        <input type="text" class="form-control" id="Term" placeholder="Term " name="Term"  value="{{$value->term}}" required>
        </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  @endforeach
  <?php } ?>
</div>

</body>
</html>
