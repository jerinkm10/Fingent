<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
;
Route::get('/student','App\Http\Controllers\HomeController@index');
Route::get('/','App\Http\Controllers\HomeController@view');
Route::get('/sudent_view/{id}','App\Http\Controllers\HomeController@editStudent');
Route::get('/delete/{id}','App\Http\Controllers\HomeController@destroy');
Route::post('/student','App\Http\Controllers\HomeController@store');
Route::post('/student_post','App\Http\Controllers\HomeController@storeput');

// mark 

Route::get('/mark','App\Http\Controllers\HomeController@mark');
Route::get('/student_mark','App\Http\Controllers\HomeController@mark_view');
Route::post('/Mark_post','App\Http\Controllers\HomeController@store_mark');
Route::get('/student_mark/{id}','App\Http\Controllers\HomeController@edit_mark');
Route::post('/mark_post','App\Http\Controllers\HomeController@mark_post');
Route::get('/delete_mark/{id}','App\Http\Controllers\HomeController@destroy_mark');

//teacher 

Route::get('/teacher','App\Http\Controllers\HomeController@teacher');
Route::get('/teacher_mark','App\Http\Controllers\HomeController@teacher_view');
Route::post('/teacher','App\Http\Controllers\HomeController@store_teacher');
Route::get('/teacher/{id}','App\Http\Controllers\HomeController@edit_teacher');
Route::post('/teacher_post','App\Http\Controllers\HomeController@teacher_post');
Route::get('/delete_teacher/{id}','App\Http\Controllers\HomeController@destroy_teacher');