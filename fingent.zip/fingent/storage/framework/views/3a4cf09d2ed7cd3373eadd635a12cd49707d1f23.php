<!DOCTYPE html>
<html lang="en">
<head>
  <title>MARK STUDENT </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Student Mark</h2>
  
  <?php if(empty($data)) {?>
    <form action="/Mark_post" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="sel1">Name:</label>
            <select class="form-control" id="Name"  name="Name" required>
            <?php   if(!empty($name)) { ?> 
                <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($values->name); ?>"><?php echo e($values->name); ?></option>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php } ?>
            </select>
        </div> 
        <div class="form-group">
        <label for="uname">Maths:</label>
        <input type="number" class="form-control" id="Maths" placeholder="Maths " name="Maths" required>
        </div>
        <div class="form-group">
        <label for="uname">Science:</label>
        <input type="number" class="form-control" id="Science" placeholder="Science " name="Science" required>
        </div>
        <div class="form-group">
        <label for="uname">History:</label>
        <input type="number" class="form-control" id="History" placeholder="History " name="History" required>
        </div>
        <div class="form-group">
        <label for="uname">Term:</label>
        <input type="text" class="form-control" id="Term" placeholder="Term " name="Term" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  <?php }else {?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form action="/mark_post" method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden"  id="id"  value='<?php echo e($value->id); ?>' name="id" >   
      <div class="form-group">
            <label for="sel1">Name:</label>
            <select class="form-control" id="Name"  name="Name" required>
            <option value="<?php echo e($value->name); ?>"><?php echo e($value->name); ?></option>  
            <?php   if(!empty($name)) { ?> 
                <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($values->name); ?>"><?php echo e($values->name); ?></option>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php } ?>
            </select>
        </div> 
        <div class="form-group">
        <label for="uname">Maths:</label>
        <input type="number" class="form-control" id="Maths" placeholder="Maths " value="<?php echo e($value->maths); ?>" name="Maths" required>
        </div>
        <div class="form-group">
        <label for="uname">Science:</label>
        <input type="number" class="form-control" id="Science" placeholder="Science "  value="<?php echo e($value->Science); ?>" name="Science" required>
        </div>
        <div class="form-group">
        <label for="uname">History:</label>
        <input type="number" class="form-control" id="History" placeholder="History " value="<?php echo e($value->History); ?>" name="History" required>
        </div>
        <div class="form-group">
        <label for="uname">Term:</label>
        <input type="text" class="form-control" id="Term" placeholder="Term " name="Term"  value="<?php echo e($value->term); ?>" required>
        </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php } ?>
</div>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\fingent\resources\views/create_mark.blade.php ENDPATH**/ ?>