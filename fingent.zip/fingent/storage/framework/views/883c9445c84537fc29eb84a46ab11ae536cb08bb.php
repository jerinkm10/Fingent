<!DOCTYPE html>
<html lang="en">
<head>
  <title>FINGENT </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Student Detaills</h2>
  
  <?php if(empty($data)) {?>
  <form action="/teacher" method="post">
      <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="uname">NAME:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name" required>
    </div>
    <div class="form-group">
      <label for="uname">Age:</label>
      <input type="text" class="form-control" id="code" placeholder="code " name="code" required>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  <?php }else {?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form action="/teacher_post" method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden"  id="id"  value='<?php echo e($value->id); ?>' name="id" >   
      <div class="form-group">
      <label for="uname">NAME:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Name" value="<?php echo e($value->name); ?>"name="name" required>
    </div>
    <div class="form-group">
      <label for="uname">Age:</label>
      <input type="text" class="form-control" id="code" placeholder="code "value="<?php echo e($value->code); ?>"name="code" required>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php } ?>
</div>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\fingent\resources\views/create_teacher.blade.php ENDPATH**/ ?>