<!DOCTYPE html>
<html lang="en">
<head>
  <title>FINGENT </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Student table</h2>
  <a href="/student "class="btn btn-success">CREATE</a>
  <a href="/mark" class="btn btn-info ">ADD MARK</a>
  <a href="/teacher" class="btn btn-info ">ADD TEACHER</a>
  <table class="table table-dark table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Age</th>
        <th>Gender</th>
        <th>Reporting Manager</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php if(!empty($data)){?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        
      <tr>
        <td><?php echo e($value->id); ?></td>
        <td><?php echo e($value->name); ?></td>
        <td><?php echo e($value->Age); ?></td>
        <td><?php echo e($value->Gender); ?></td>
        <?php if(!empty($reportingmanager)) {?>
          <?php $__currentLoopData = $reportingmanager; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($values->code == $value->teacher ): ?>
              <td><?php echo e($values->name); ?></td>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php } ?>
        <td><a href="/sudent_view/<?php echo e($value->id); ?>" class="btn btn-success btn-sm">edit</a>
        
        <a href="/delete/<?php echo e($value->id); ?>" class="btn btn-danger btn-sm">Delete</a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php } ?>
    </tbody>
  </table>
</div>

</body>
</html>
<?php /**PATH D:\xampp\htdocs\fingent\resources\views/sudenttable.blade.php ENDPATH**/ ?>